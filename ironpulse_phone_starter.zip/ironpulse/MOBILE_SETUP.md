# IronPulse — Android phone workflow

This project can be edited on an Android phone with Acode. Acode is a code editor; it does not include the Flutter/Android build toolchain. We will use GitHub Actions as the cloud build machine.

## What you need
- Acode installed on your Android phone
- A GitHub account and a browser
- The IronPulse project folder extracted from the ZIP

## Step 1 — Extract and open
1. Extract `ironpulse_phase1.zip` using your phone's file manager.
2. Open Acode and choose **Open Folder**.
3. Select the extracted `ironpulse` folder (the one containing `pubspec.yaml`).
4. Keep the folder name and file structure unchanged.

## Step 2 — Upload to GitHub
1. In your browser, sign in to GitHub and create a new repository named `ironpulse`.
2. Set it to **Private** while the project is under development.
3. Upload the contents of this `ironpulse` folder to the repository root. Do not upload the outer parent folder as an extra nesting level.
4. Confirm that `pubspec.yaml`, `lib/`, `test/`, `docs/`, `.github/`, and `assets/` are visible at the repository root.

## Step 3 — Build in the cloud
1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Build IronPulse Android APK**.
4. Tap **Run workflow** and confirm.
5. When the workflow finishes successfully, open that workflow run and download the `ironpulse-debug-apk` artifact.
6. Extract the downloaded artifact to get `app-debug.apk`.

## Important Firebase note
The current source calls `Firebase.initializeApp()` and uses Firebase Authentication/Firestore. The ZIP does not include the Android platform folder or Firebase's `google-services.json` / generated FlutterFire options. The workflow can compile the starter, but Firebase must be configured before the app can run correctly on a device. Never upload private service-account keys or API secrets to a public repository.

## Current project scope
This is a starter foundation, not a finished fitness app. Most feature screens are placeholders. Build and test the foundation first, then implement features in small phases.
