import 'package:flutter_test/flutter_test.dart';
import 'package:ironpulse/core/utils/nutrition_calculators.dart';

void main() {
  group('NutritionCalculators', () {
    test('BMR (Mifflin-St Jeor) male 80kg 180cm 30y', () {
      final bmr = NutritionCalculators.bmr(
        sex: Sex.male,
        weightKg: 80,
        heightCm: 180,
        age: 30,
      );
      expect(bmr, closeTo(1780, 0.01)); // 800 + 1125 - 150 + 5
    });

    test('BMR female 60kg 165cm 25y', () {
      final bmr = NutritionCalculators.bmr(
        sex: Sex.female,
        weightKg: 60,
        heightCm: 165,
        age: 25,
      );
      expect(bmr, closeTo(1345.25, 0.01)); // 600 + 1031.25 - 125 - 161
    });

    test('goal adjusts calories', () {
      expect(NutritionCalculators.targetCalories(2500, FitnessGoal.loseFat), 2000);
      expect(NutritionCalculators.targetCalories(2500, FitnessGoal.maintain), 2500);
    });

    test('macros add up close to the calorie target', () {
      final m = NutritionCalculators.macros(
        weightKg: 80,
        calories: 2800,
        goal: FitnessGoal.buildMuscle,
      );
      final total = m.proteinG * 4 + m.carbsG * 4 + m.fatG * 9;
      expect((total - m.calories).abs(), lessThan(20));
      expect(m.proteinG, 160);
    });

    test('Epley 1RM', () {
      expect(NutritionCalculators.estimatedOneRepMax(100, 10), closeTo(133.33, 0.01));
      expect(NutritionCalculators.estimatedOneRepMax(100, 1), 100);
    });
  });
}
