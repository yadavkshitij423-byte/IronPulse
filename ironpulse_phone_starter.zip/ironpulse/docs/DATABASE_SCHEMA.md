# Firestore Schema

Conventions: camelCase fields, `createdAt`/`updatedAt` server timestamps, soft-delete via `deletedAt` where sync matters. Units stored metric (kg, cm); converted in UI.

## Top-level collections (shared data)

### exercises/{exerciseId}
`name, slug, category (strength|cardio|mobility), primaryMuscles[], secondaryMuscles[], equipment[], difficulty, mechanic, instructions[], tips[], commonMistakes[], safetyWarnings[], imageUrls[], animationUrl, isCustom, updatedAt`

### challenges/{challengeId}
`title, type (muscle30|fatloss|beginner|strength), durationDays, days[{day, workoutRef, task}], coverUrl, isPremium`

### foods/{foodId}
`name, brand, servingSize, servingUnit, calories, proteinG, carbsG, fatG, fiberG, barcode, source`

### recipes/{recipeId}
`title, ingredients[{foodId, qty}], steps[], macrosPerServing, imageUrl, tags[]`

### posts/{postId}
`authorId, authorName, authorPhoto, text, imageUrls[], workoutSummary?, likeCount, commentCount, createdAt`
- subcollections: `comments/{id}` (authorId, text, createdAt), `likes/{uid}`

### follows/{followerId_followedId}
`followerId, followedId, createdAt`

### reports/{id}
`targetType, targetId, reporterId, reason, status, createdAt`

## Per-user data: users/{uid}

### users/{uid} (profile)
`name, email, photoUrl, isGuest, age, gender, heightCm, weightKg, bodyFatPct, experience, goal, activityLevel, injuries[], equipment[], units, isPremium, premiumUntil, fcmTokens[], reminders{workout, meal, water, sleep}, createdAt`

### Subcollections
- `workoutPlans/{planId}`: name, split, daysPerWeek, days[{name, exercises[{exerciseId, sets, repsMin, repsMax, restSec, tempo, rpe, targetMuscles[]}], warmup[], cooldown[]}], generatedBy (rules|ai)
- `workoutLogs/{logId}`: planId?, dayName, startedAt, endedAt, durationSec, volumeKg, sets[{exerciseId, setNo, reps, weightKg, rpe, isWarmup}], prs[]
- `personalRecords/{exerciseId}`: bestWeightKg, bestReps, best1RM, achievedAt, logId
- `meals/{yyyy-MM-dd}`: entries[{mealType, foodId, name, qty, calories, proteinG, carbsG, fatG}], totals, waterMl
- `mealPlans/{planId}`: days[...], targetMacros
- `progress/{entryId}`: date, weightKg, bodyFatPct, measurements{chest, waist, hips, arm, thigh}, photoUrls[]
- `challengeEnrollments/{challengeId}`: startedAt, completedDays[], status
- `aiConversations/{convId}`: title, createdAt; `messages/{id}`: role, text, createdAt
- `reports/{yyyy-MM}`: generated monthly summary + pdfUrl

## Indexes needed
- `workoutLogs`: startedAt desc
- `posts`: createdAt desc; (authorId, createdAt desc)
- `progress`: date desc
- `exercises`: (primaryMuscles array-contains, name)

## Storage layout
`users/{uid}/progress/{file}`, `users/{uid}/avatar.jpg`, `posts/{postId}/{file}`, `exercises/{id}/{file}` (admin-write)

## Server-maintained fields (Cloud Functions only)
`likeCount`, `commentCount`, `isPremium` (from store webhook), leaderboards, monthly reports.
