# IronPulse – Architecture

## Stack
- Flutter (stable), Material 3, Dart 3
- State management: Riverpod (riverpod_annotation + hooks optional)
- Routing: go_router (with auth redirect guard)
- Backend: Firebase Auth, Firestore (offline persistence on), Storage, FCM, Cloud Functions (TypeScript)
- Local cache: Drift (SQLite) for exercise library + queued workout logs
- Charts: fl_chart
- AI Coach: Cloud Function proxy -> LLM API (key never in the app); quota enforced server-side by premium flag

## Clean Architecture (feature-first)
Each feature has three layers:
- `domain/`  entities, repository interfaces, use cases (pure Dart, no Flutter/Firebase)
- `data/`    DTO models, Firestore/remote/local data sources, repository implementations
- `presentation/` screens, widgets, Riverpod controllers

Dependency rule: presentation -> domain <- data.

## Folder structure
```
lib/
  main.dart
  app.dart
  bootstrap.dart
  core/
    theme/            app_theme.dart, colors, typography, glass widgets
    router/           app_router.dart
    errors/           failures.dart
    utils/            formatters, calculators (TDEE, macros, 1RM)
    widgets/          GlassCard, NeonButton, shimmer, charts
    services/         notifications, connectivity, analytics
  features/
    auth/             login, signup, guest, reset, apple/google
    onboarding/       profile collection
    profile/
    workouts/         generator, plans, templates
    exercises/        library (1000+), detail, search/filter
    tracking/         active workout, rest timer, PRs, history, calendar
    nutrition/        macros, food db, meal planner, water, recipes
    progress/         weight, body fat, measurements, photos, reports
    challenges/
    community/        posts, comments, likes, follow, feed
    ai_coach/         chat, plan builder, injury modifications
    premium/          paywall, entitlements (RevenueCat)
    notifications/
    settings/
admin/                Flutter Web admin dashboard (separate target) 
functions/            Cloud Functions (TypeScript)
test/  integration_test/
```

## Offline & sync
Firestore persistence for user data; Drift cache for exercise catalog (seeded from bundled JSON, delta-synced by `updatedAt`). Active workouts are written locally first and synced on reconnect.

## Security
- Firestore rules: owner-only user data, public read of catalog, admin via custom claim `admin: true`
- AI and premium checks only in Cloud Functions
- App Check enabled

## Roadmap (incremental, each phase tested before next)
1. Foundation (this phase)
2. Auth + onboarding + profile
3. Exercise library + seed data pipeline
4. Workout tracking (logging, rest timer, PRs, history)
5. Workout generator (rule-based engine, then AI refinement)
6. Nutrition
7. Progress + photos + reports (PDF export)
8. AI Coach (Cloud Functions)
9. Challenges + Community
10. Premium, notifications, admin panel
11. QA, performance, store release

## Honest scope notes
- 1000+ exercises with images/animations require a licensed dataset or media (e.g. wger, ExerciseDB, or commissioned content). Code can't invent assets; the pipeline will ingest a dataset you choose.
- Apple Sign-In requires a paid Apple Developer account; store release needs your Firebase/store credentials.
