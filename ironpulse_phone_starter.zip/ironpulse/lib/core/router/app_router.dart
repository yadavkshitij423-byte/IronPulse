import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

/// Route paths in one place to avoid stringly-typed navigation.
class Routes {
  Routes._();
  static const splash = '/';
  static const login = '/login';
  static const onboarding = '/onboarding';
  static const home = '/home';
  static const workouts = '/workouts';
  static const nutrition = '/nutrition';
  static const progress = '/progress';
  static const coach = '/coach';
  static const community = '/community';
}

/// Exposes Firebase auth state as a stream provider.
final authStateProvider = StreamProvider<User?>(
  (ref) => FirebaseAuth.instance.authStateChanges(),
);

/// Bridges a Riverpod stream to GoRouter's refreshListenable.
class _AuthRefresh extends ChangeNotifier {
  _AuthRefresh(Ref ref) {
    ref.listen(authStateProvider, (_, __) => notifyListeners());
  }
}

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = _AuthRefresh(ref);

  return GoRouter(
    initialLocation: Routes.splash,
    refreshListenable: refresh,
    redirect: (context, state) {
      final auth = ref.read(authStateProvider);
      if (auth.isLoading) return Routes.splash;

      final loggedIn = auth.valueOrNull != null; // guests count (anonymous)
      final atAuth = state.matchedLocation == Routes.login;

      if (!loggedIn) return atAuth ? null : Routes.login;
      if (atAuth || state.matchedLocation == Routes.splash) return Routes.home;
      return null;
    },
    routes: [
      GoRoute(path: Routes.splash, builder: (_, __) => const _Placeholder('Splash')),
      GoRoute(path: Routes.login, builder: (_, __) => const _Placeholder('Login')),
      GoRoute(path: Routes.onboarding, builder: (_, __) => const _Placeholder('Onboarding')),
      // Bottom-nav shell: tabs keep their own navigation stacks.
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => _MainShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.home, builder: (_, __) => const _Placeholder('Home')),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.workouts, builder: (_, __) => const _Placeholder('Workouts')),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.nutrition, builder: (_, __) => const _Placeholder('Nutrition')),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.progress, builder: (_, __) => const _Placeholder('Progress')),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.coach, builder: (_, __) => const _Placeholder('AI Coach')),
          ]),
        ],
      ),
    ],
  );
});

class _MainShell extends StatelessWidget {
  const _MainShell({required this.shell});
  final StatefulNavigationShell shell;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: shell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: shell.currentIndex,
        onDestinationSelected: (i) =>
            shell.goBranch(i, initialLocation: i == shell.currentIndex),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.fitness_center), label: 'Train'),
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), label: 'Eat'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.smart_toy_outlined), label: 'Coach'),
        ],
      ),
    );
  }
}

/// Temporary screen until each feature phase replaces it.
class _Placeholder extends StatelessWidget {
  const _Placeholder(this.name);
  final String name;

  @override
  Widget build(BuildContext context) =>
      Scaffold(body: Center(child: Text(name)));
}
