import 'dart:ui';

import 'package:flutter/material.dart';

/// Glassmorphism card: blurred backdrop, translucent fill, hairline border.
///
/// Note: BackdropFilter is costly. Avoid nesting many of these in long
/// scrolling lists; wrap in RepaintBoundary (done here) to protect 60 FPS.
class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 20,
    this.blur = 14,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final double blur;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fill = isDark
        ? Colors.white.withOpacity(0.06)
        : Colors.white.withOpacity(0.65);
    final border = isDark
        ? Colors.white.withOpacity(0.12)
        : Colors.black.withOpacity(0.06);

    return RepaintBoundary(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Material(
            color: fill,
            child: InkWell(
              onTap: onTap,
              child: Container(
                padding: padding,
                decoration: BoxDecoration(
                  border: Border.all(color: border),
                  borderRadius: BorderRadius.circular(radius),
                ),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
