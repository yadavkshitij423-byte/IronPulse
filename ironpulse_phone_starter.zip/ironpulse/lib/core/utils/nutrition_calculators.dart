/// Pure-Dart nutrition and strength calculators (no Flutter deps => easy to test).
library;

enum Sex { male, female }

enum ActivityLevel {
  sedentary(1.2),
  light(1.375),
  moderate(1.55),
  active(1.725),
  veryActive(1.9);

  const ActivityLevel(this.multiplier);
  final double multiplier;
}

enum FitnessGoal { buildMuscle, loseFat, maintain, strength, endurance }

class Macros {
  const Macros({
    required this.calories,
    required this.proteinG,
    required this.carbsG,
    required this.fatG,
  });
  final int calories;
  final int proteinG;
  final int carbsG;
  final int fatG;
}

class NutritionCalculators {
  NutritionCalculators._();

  /// Basal metabolic rate, Mifflin-St Jeor equation.
  static double bmr({
    required Sex sex,
    required double weightKg,
    required double heightCm,
    required int age,
  }) {
    final base = 10 * weightKg + 6.25 * heightCm - 5 * age;
    return sex == Sex.male ? base + 5 : base - 161;
  }

  /// Total daily energy expenditure.
  static double tdee(double bmr, ActivityLevel level) => bmr * level.multiplier;

  /// Calorie target adjusted for goal (+10% surplus, -20% deficit).
  static double targetCalories(double tdee, FitnessGoal goal) {
    switch (goal) {
      case FitnessGoal.buildMuscle:
        return tdee * 1.10;
      case FitnessGoal.loseFat:
        return tdee * 0.80;
      case FitnessGoal.strength:
        return tdee * 1.05;
      case FitnessGoal.maintain:
      case FitnessGoal.endurance:
        return tdee;
    }
  }

  /// Daily protein target in grams per kg bodyweight (evidence-based ranges:
  /// ~1.6-2.2 g/kg for muscle gain; higher end during a cut).
  static double proteinGrams(double weightKg, FitnessGoal goal) {
    final perKg = switch (goal) {
      FitnessGoal.loseFat => 2.2,
      FitnessGoal.buildMuscle => 2.0,
      FitnessGoal.strength => 1.8,
      FitnessGoal.maintain => 1.6,
      FitnessGoal.endurance => 1.6,
    };
    return weightKg * perKg;
  }

  /// Full macro split: protein by bodyweight, fat at 25% of calories,
  /// carbs fill the remainder.
  static Macros macros({
    required double weightKg,
    required double calories,
    required FitnessGoal goal,
  }) {
    final protein = proteinGrams(weightKg, goal);
    final fat = (calories * 0.25) / 9;
    final carbs = (calories - protein * 4 - fat * 9) / 4;
    return Macros(
      calories: calories.round(),
      proteinG: protein.round(),
      carbsG: carbs.clamp(0, double.infinity).round(),
      fatG: fat.round(),
    );
  }

  /// Estimated one-rep max, Epley formula.
  static double estimatedOneRepMax(double weight, int reps) =>
      reps <= 1 ? weight : weight * (1 + reps / 30);
}
