import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

/// Builds Material 3 light and dark themes.
class AppTheme {
  AppTheme._();

  static ThemeData get dark => _build(
        ColorScheme.fromSeed(
          seedColor: AppColors.neonLime,
          brightness: Brightness.dark,
        ).copyWith(
          primary: AppColors.neonLime,
          secondary: AppColors.neonCyan,
          tertiary: AppColors.neonMagenta,
          surface: AppColors.darkSurface,
          error: AppColors.danger,
        ),
        scaffoldBg: AppColors.darkBg,
      );

  static ThemeData get light => _build(
        ColorScheme.fromSeed(
          seedColor: AppColors.neonLime,
          brightness: Brightness.light,
        ).copyWith(
          primary: const Color(0xFF4F8A00),
          secondary: const Color(0xFF008FA0),
          tertiary: const Color(0xFFC2127A),
          surface: AppColors.lightSurface,
          error: AppColors.danger,
        ),
        scaffoldBg: AppColors.lightBg,
      );

  static ThemeData _build(ColorScheme scheme, {required Color scaffoldBg}) {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scaffoldBg,
    );
    final textTheme = GoogleFonts.interTextTheme(base.textTheme).copyWith(
      displayLarge: GoogleFonts.barlowCondensed(
        fontSize: 56,
        fontWeight: FontWeight.w800,
        color: scheme.onSurface,
      ),
      headlineMedium: GoogleFonts.barlowCondensed(
        fontSize: 30,
        fontWeight: FontWeight.w700,
        color: scheme.onSurface,
      ),
    );

    return base.copyWith(
      textTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.titleLarge,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: scheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest.withOpacity(0.4),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: scheme.surface.withOpacity(0.85),
        indicatorColor: scheme.primary.withOpacity(0.2),
      ),
    );
  }
}
