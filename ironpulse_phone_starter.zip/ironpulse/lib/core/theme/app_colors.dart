import 'package:flutter/material.dart';

/// Central colour tokens for IronPulse. Neon accents on deep charcoal.
class AppColors {
  AppColors._();

  // Neon accents
  static const neonLime = Color(0xFFB6FF3B);
  static const neonCyan = Color(0xFF22E3F5);
  static const neonMagenta = Color(0xFFFF3DAE);
  static const neonOrange = Color(0xFFFF8A2B);

  // Dark surfaces
  static const darkBg = Color(0xFF0B0D12);
  static const darkSurface = Color(0xFF141821);
  static const darkSurfaceHigh = Color(0xFF1C2230);

  // Light surfaces
  static const lightBg = Color(0xFFF5F7FA);
  static const lightSurface = Color(0xFFFFFFFF);

  // Semantic
  static const success = Color(0xFF3DDC84);
  static const warning = Color(0xFFFFC53D);
  static const danger = Color(0xFFFF5C5C);

  // Macro colours (used by charts & rings)
  static const protein = neonCyan;
  static const carbs = neonLime;
  static const fat = neonOrange;
}
