import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Run `flutterfire configure` to generate firebase_options.dart, then pass
  // `options: DefaultFirebaseOptions.currentPlatform` here.
  await Firebase.initializeApp();

  // Offline-first: Firestore caches reads/writes and syncs automatically.
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );

  runApp(const ProviderScope(child: IronPulseApp()));
}
